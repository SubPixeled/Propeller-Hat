package com.dfrobot.angelo.blunopropellerhat;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Toast;

import java.util.List;

public class MainActivity  extends BlunoLibrary {
	private Button buttonScan;
	private Button TwentyFive;
	private Button FiftyPercent;
	private Button SeventyFive;
	private Button OneHundred;
	SeekBar simpleSeekBar;
	RelativeLayout relativeLayout;

	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		relativeLayout = findViewById(R.id.relativeLayout);
		GradientDrawable gradient = new GradientDrawable(
				GradientDrawable.Orientation.TOP_BOTTOM,
				new int[] {Color.parseColor("#000046"), Color.parseColor("#1CB5E0")});

		relativeLayout.setBackground(gradient);

		request(1000, new OnPermissionsResult() {
			@Override
			public void OnSuccess() {
				Toast.makeText(MainActivity.this,"success",Toast.LENGTH_SHORT).show();
			}

			@Override
			public void OnFail(List<String> noPermissions) {
				Toast.makeText(MainActivity.this,"fail",Toast.LENGTH_SHORT).show();
			}
		});
        onCreateProcess();														//onCreate Process by BlunoLibrary


        serialBegin(115200);													//set the Uart Baudrate on BLE chip to 115200

        buttonScan = (Button) findViewById(R.id.buttonScan);					//initial the button for scanning the BLE device
        buttonScan.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				buttonScanOnClickProcess();										//Alert Dialog for selecting the BLE device
			}
		});

		TwentyFive = (Button) findViewById(R.id.TwentyFiveButton);				//initial the button for sending 25% to the Arduino
		TwentyFive.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				serialSendInt(25);												//send 25% to the Arduino
			}
		});

		FiftyPercent = (Button) findViewById(R.id.FiftyButton);					//initial the button for sending 50% to the Arduino
		FiftyPercent.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				serialSendInt(50);												//send 50% to the Arduino
			}
		});

		SeventyFive = (Button) findViewById(R.id.SeventyFiveButton);				//initial the button for sending 75% to the Arduino
		SeventyFive.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				serialSendInt(75);												//send 75% to the Arduino
			}
		});

		OneHundred = (Button) findViewById(R.id.OneHundredButton);				//initial the button for sending 100% to the Arduino
		OneHundred.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				serialSendInt(100);												//send 100% to the Arduino
			}
		});


        simpleSeekBar=(SeekBar)findViewById(R.id.simpleSeekBar);
		// perform seek bar change listener event used for getting the progress value
		simpleSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			int progressChangedValue=0;

			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
				progressChangedValue = progress;
			}

			public void onStartTrackingTouch(SeekBar seekBar) {
				// TODO Auto-generated method stub
			}

			public void onStopTrackingTouch(SeekBar seekBar) {
				Toast.makeText(MainActivity.this, "Seek bar progress is :" + progressChangedValue,
						Toast.LENGTH_SHORT).show();
				serialSendInt(progressChangedValue);
			}
		});

	}

	protected void onResume(){
		super.onResume();
		System.out.println("BlUNOActivity onResume");
		onResumeProcess();														//onResume Process by BlunoLibrary
	}
	
	
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		onActivityResultProcess(requestCode, resultCode, data);					//onActivityResult Process by BlunoLibrary
		super.onActivityResult(requestCode, resultCode, data);
	}
	
    @Override
    protected void onPause() {
        super.onPause();
        onPauseProcess();														//onPause Process by BlunoLibrary
    }
	
	protected void onStop() {
		super.onStop();
		onStopProcess();														//onStop Process by BlunoLibrary
	}
    
	@Override
    protected void onDestroy() {
        super.onDestroy();	
        onDestroyProcess();														//onDestroy Process by BlunoLibrary
    }

	@Override
	public void onConectionStateChange(connectionStateEnum theConnectionState) {//Once connection state changes, this function will be called
		switch (theConnectionState) {											//Four connection state
		case isConnected:
			buttonScan.setText("Connected");
			break;
		case isConnecting:
			buttonScan.setText("Connecting");
			break;
		case isToScan:
			buttonScan.setText("Scan");
			break;
		case isScanning:
			buttonScan.setText("Scanning");
			break;
		case isDisconnecting:
			buttonScan.setText("isDisconnecting");
			break;
		default:
			break;
		}
	}



}